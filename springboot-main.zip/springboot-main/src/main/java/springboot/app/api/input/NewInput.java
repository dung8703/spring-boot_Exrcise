package springboot.app.api.input;

public class NewInput {
    
}
